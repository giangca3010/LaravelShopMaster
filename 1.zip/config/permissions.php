<?php

return[
    'access' => [
        'list-category' => 'category_list',
        'list-menu' => 'menu_list',

    ],
    'table_module'=>[
        'category',
        'menu',
        'slider',
        'product',
        'setting',
        'user',
        'role',
        'test'
    ],
    'module_children'=>[
        'list',
        'add',
        'edit',
        'delete',
    ]

];
