<?php $__env->startSection('title'); ?>
    <title>Home page</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('home/home.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <link href="<?php echo e(asset('home/home.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!--/slider-->
    <?php echo $__env->make('home.component.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--/slider-->

    <section>
        <div class="container">
            <div class="row">
                <?php echo $__env->make('componentShow.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="col-sm-9 padding-right">
                    <!--features_items-->
                    <?php echo $__env->make('home.component.feature_product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!--features_items-->

                    <!--/category-tab-->
                    <?php echo $__env->make('home.component.categry_tabs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!--/category-tab-->

                    <!--/recommended_items-->
                    <?php echo $__env->make('home.component.recomment_product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!--/recommended_items-->

                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layoutsShow.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/giangca/Documents/LaravelMaster/resources/views/home/home.blade.php ENDPATH**/ ?>