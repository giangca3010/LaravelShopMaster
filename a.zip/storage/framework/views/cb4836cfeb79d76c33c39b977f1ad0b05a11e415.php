<div class="recommended_items">
    <h2 class="title text-center">Sản phẩm nổi bật</h2>

    <div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">


            <?php $__currentLoopData = $productRecomment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyRecomment => $productRecommentItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($keyRecomment % 3 == 0): ?>
                    <div class="item <?php echo e($keyRecomment == 0 ? 'active' : ''); ?>active">
                <?php endif; ?>
                        <div class="col-sm-4">
                            <div class="product-image-wrapper">
                                <div class="single-products">
                                    <div class="productinfo text-center">
                                        <img src="<?php echo e(config('app.base_url') . $productRecommentItem->feature_image_path); ?>" alt=""/>
                                        <h2><?php echo e(number_format($productRecommentItem->price)); ?> VND</h2>
                                        <p><?php echo e($productRecommentItem->name); ?></p>
                                        <a href="#" class="btn btn-default add-to-cart"><i
                                                class="fa fa-shopping-cart"></i>Add to cart</a>
                                    </div>

                                </div>
                            </div>
                        </div>
                <?php if($keyRecomment % 3 == 2): ?>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <a class="left recommended-item-control" href="#recommended-item-carousel"
           data-slide="prev">
            <i class="fa fa-angle-left"></i>
        </a>
        <a class="right recommended-item-control" href="#recommended-item-carousel"
           data-slide="next">
            <i class="fa fa-angle-right"></i>
        </a>
    </div>
</div>

<?php /**PATH /home/giangca/Documents/LaravelMaster/resources/views/home/component/recomment_product.blade.php ENDPATH**/ ?>