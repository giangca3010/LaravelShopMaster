<?php $__env->startSection('title'); ?>
    <title>Trang chủ</title>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <?php echo $__env->make('partials.content-header', ['name' => 'Settings', 'key' => 'Add'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        <form action="<?php echo e(route('settings.store') . '?type=' . request()->type); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Config key</label>
                                <input type="text" class="form-control <?php if ($errors->has('config_key')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('config_key'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="config_key" placeholder="Nhập config key">
                                <?php if ($errors->has('config_key')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('config_key'); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>

                            <?php if(request()->type ==='Text'): ?>
                                <div class="form-group">
                                    <label>Config value</label>
                                    <input type="text" class="form-control <?php if ($errors->has('config_value')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('config_value'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="config_value"
                                           placeholder="Nhập config value">
                                    <?php if ($errors->has('config_value')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('config_value'); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            <?php elseif(request()->type ==='Textarea'): ?>
                                <div class="form-group">
                                    <label>Config value</label>
                                    <textarea rows="5" class="form-control <?php if ($errors->has('config_value')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('config_value'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="config_value"
                                           placeholder="Nhập config value"></textarea>
                                    <?php if ($errors->has('config_value')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('config_value'); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            <?php endif; ?>

                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/giangca/Documents/LaravelMaster/resources/views/admin/setting/add.blade.php ENDPATH**/ ?>