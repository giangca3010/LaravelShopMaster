<?php if($categoryParent->categoryChildren->count()): ?>
    <ul role="menu" class="sub-menu">
        <?php $__currentLoopData = $categoryParent->categoryChildren; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryChil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('categoryShow.product', ['slug'=>$categoryChil->slug, 'id'=>$categoryChil->id])); ?>"><?php echo e($categoryChil->name); ?></a>
                <?php if($categoryChil->categoryChildren ->count()): ?>
                    <?php echo $__env->make('componentShow.child_menu', ['categoryParent'=>$categoryChil], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>
<?php /**PATH /home/giangca/Documents/LaravelMaster/resources/views/componentShow/child_menu.blade.php ENDPATH**/ ?>