<div class="mainmenu pull-left">
    <ul class="nav navbar-nav collapse navbar-collapse">
        <li><a href="<?php echo e(route('news')); ?>" class="active">Home</a></li>

        <?php $__currentLoopData = $categoriesLimit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryParent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="dropdown"><a href="#">
                    <?php echo e($categoryParent->name); ?>

                    <i class="fa fa-angle-down"></i></a>
                <?php echo $__env->make('componentShow.child_menu', ['categoryParent'=>$categoryParent], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH /home/giangca/Documents/LaravelMaster/resources/views/componentShow/main_menu.blade.php ENDPATH**/ ?>