<footer id="footer"><!--Footer-->

    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <?php echo getConfigValueFormSettingTable('Footer_infomation')->config_value; ?>


            </div>
        </div>
    </div>

</footer><!--/Footer-->
<?php /**PATH /home/giangca/Documents/LaravelMaster/resources/views/componentShow/footer.blade.php ENDPATH**/ ?>