<h2>Khong duoc truy cap</h2>
<?php /**PATH /home/giangca/Documents/LaravelMaster/resources/views/errors/403.blade.php ENDPATH**/ ?>